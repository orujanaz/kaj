var firstname = document.forms['signupForm']['firstname'];
var lastname = document.forms['signupForm']['lastname'];
var email = document.forms['signupForm']['email'];
var password = document.forms['signupForm']['password'];

var email2 = document.forms['loginForm']['email2'];
var password2 = document.forms['loginForm']['password2'];

var signup_error = document.querySelector('.signup_error');
var login_error = document.querySelector('.login_error');

firstname.addEventListener('textInput', fstnameVerify);
lastname.addEventListener('textInput', lstnameVerify);
email.addEventListener('textInput', emailVerify);
password.addEventListener('textInput', passwordVerify);

email2.addEventListener('textInput', emailVerify2);
password2.addEventListener('textInput', passwordVerify2);

/** Validace jmena, prijmeni, emailu a hesla v registracnim formulare. **/
function signupValid(){
    if(firstname.value.length <= 2){
        signup_error.style.display = "block";
        firstname.style.border = "1px solid red";
        signup_error.innerText = "Please Fill up Your Firstname"
        firstname.focus();
        return false;
    }
    if(lastname.value.length <= 2){
        signup_error.style.display = "block";
        lastname.style.border = "1px solid red";
        signup_error.innerText = "Please Fill up Your Lastname"
        lastname.focus();
        return false;
    }
    if(email.value.length <= 8){
        signup_error.style.display = "block";
        email.style.border = "1px solid red";
        signup_error.innerText = "Please Fill up Your Email"
        email.focus();
        return false;
    }
    if(password.value.length <= 3){
        signup_error.style.display = "block";
        password.style.border = "1px solid red";
        signup_error.innerText = "Please Fill up Your Password"
        password.focus();
        return false;
    }

}

/** Validace jmena, prijmeni, emailu a hesla v prihlasovacim formulare. **/
function loginValid(){
    if(email2.value.length <= 8){
        login_error.style.display = "block";
        email2.style.border = "1px solid red";
        login_error.innerText = "Please Fill up Your Email"
        email2.focus();
        return false;
    }
    if(password2.value.length <= 3){
        login_error.style.display = "block";
        password2.style.border = "1px solid red";
        login_error.innerText = "Please Fill up Your Password"
        password2.focus();
        return false;
    }

}

/** Validace jmena v registracnim formulare. Delka jmena musi byt vice nez 1. **/
function fstnameVerify(){
    if (firstname.value.length > 1) {
        signup_error.style.display = "none";
        firstname.style.border = "1px solid #3498db";
        signup_error.innerText = "";
        return true;
    }
}
/** V
 * alidace prijmeni v registracnim formulare. Delka prijmeni musi byt vice nez 1. **/
function lstnameVerify(){
    if (lastname.value.length > 1) {
        signup_error.style.display = "none";
        lastname.style.border = "1px solid #3498db";
        signup_error.innerText = "";
        return true;
    }
}

/** Validace email v registracnim formulare. Delka emailu musi byt vice nez 7. **/
function emailVerify(){
    if (email.value.length > 7) {
        signup_error.style.display = "none";
        email.style.border = "1px solid #3498db";
        signup_error.innerText = "";
        return true;
    }
}

/** Validace jmena v registracnim formulare. Delka hesla musi byt vice nez 2. **/
function passwordVerify(){
    if (password.value.length > 2) {
        signup_error.style.display = "none";
        password.style.border = "1px solid #3498db";
        signup_error.innerText = "";
        return true;
    }
}

/** Validace email v prihlasovacim formulare. Delka musi byt vice nez 7. **/
function emailVerify2(){
    if (email2.value.length > 7) {
        login_error.style.display = "none";
        email2.style.border = "1px solid #3498db";
        login_error.innerText = "";
        return true;
    }
}

/** Validace jmena v prihlasovacim formulare. Delka jmena musi byt vice nez 2. **/
function passwordVerify2(){
    if (password2.value.length > 2) {
        login_error.style.display = "none";
        password2.style.border = "1px solid #3498db";
        login_error.innerText = "";
        return true;
    }
}